package com.capgemini.capstore;

import com.capgemini.capstore.beans.ProductFeedback;

public class RestResponseFeedback {
	
	private ProductFeedback productFeedback;

	public ProductFeedback getProductFeedback() {
		return productFeedback;
	}

	public void setProductFeedback(ProductFeedback productFeedback) {
		this.productFeedback = productFeedback;
	}

	public RestResponseFeedback() {
		super();
	}
	

}
