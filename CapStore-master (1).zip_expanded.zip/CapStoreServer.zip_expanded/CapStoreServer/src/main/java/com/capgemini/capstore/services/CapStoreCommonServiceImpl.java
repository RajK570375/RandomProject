package com.capgemini.capstore.services;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.User;
import com.capgemini.capstore.dao.ICapStoreUserDAO;
import com.capgemini.capstore.util.MD5;

@Service
public class CapStoreCommonServiceImpl implements ICapStoreCommonService {
	
	@Autowired
	ICapStoreUserDAO userRepo;

	@Override
	public boolean ValidateLogIn(@Valid User user) {
		
		User result = null;
		try {
			result = userRepo.findById(user.getEmailId()).get();
			// System.out.println(result.getEmailId()+" "+result.getPassword());
		} catch (Exception e) {

			e.printStackTrace();
		}
		if (result != null) {
			MD5 encryption = new MD5();
			user.setPassword(encryption.encryptText(user.getPassword()));
			if (result.equals(user)) {
				return true;
			}
			return false;
		}
		return false;	}

	@Override
	public String isValidEmail(String email) {
		try {
			User user = userRepo.findById(email).get();
			return user.getSecurityQuestion();
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public boolean checkSequirityAnswer(String email, String sequirityAnswer) {
		try {
			User user = userRepo.findById(email).get();
			if (user.getSecurityAnswer().equalsIgnoreCase(sequirityAnswer)) {
				return true;
			}
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public void updatePassword(String email, String password) {
		MD5 encryption = new MD5();
		password = encryption.encryptText(password);
		try {
			User user = userRepo.findById(email).get();
			user.setPassword(password);
			userRepo.save(user);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public boolean changePassword(String email, String oldPassword, String newPassword) {
		MD5 encryption = new MD5();
		oldPassword = encryption.encryptText(oldPassword);
		newPassword = encryption.encryptText(newPassword);
		try {
			User user = userRepo.findById(email).get();
			if (user.getPassword().equals(oldPassword)) {
				user.setPassword(newPassword);
				userRepo.save(user);
				return true;
			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean ValidateUserDetails(@Valid User user) {
		MD5 encryption = new MD5();
		user.setPassword(encryption.encryptText(user.getPassword()));
		Optional<User> result = userRepo.findById(user.getEmailId());
		if (result.isPresent()) {
			return false;
		}
		userRepo.save(user);
		return true;
	}


	
}
