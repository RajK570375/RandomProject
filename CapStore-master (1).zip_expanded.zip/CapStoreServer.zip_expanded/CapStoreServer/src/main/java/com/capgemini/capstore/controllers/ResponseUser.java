package com.capgemini.capstore.controllers;



public class ResponseUser {

	
	private RestResponseUser restResponseUser;

	public RestResponseUser getRestResponseUser() {
		return restResponseUser;
	}

	public void setRestResponseUser(RestResponseUser restResponseUser) {
		this.restResponseUser = restResponseUser;
	}

	public ResponseUser() {
		super();
	}
}
