package com.capgemini.capstore.main.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.beans.ProductFeedback;
import com.capgemini.capstore.main.dao.CapStoreCustomer;
import com.capgemini.capstore.main.dao.CapStoreProduct;
import com.capgemini.capstore.main.dao.CapStoreProductFeedback;

@Transactional
@Service
public class CapstoreService {

	@Autowired
	private CapStoreProductFeedback capStoreFeedback;

	@Autowired
	private CapStoreProduct capStoreProduct;

	@Autowired
	private CapStoreCustomer capStoreCustomer;

	public ProductFeedback setFeedback(ProductFeedback productFeedback) {

		// entityManager.persist(feedback);
		capStoreFeedback.save(productFeedback);

		return productFeedback;

	}

	public List<ProductFeedback> getAll(int product_Id) {

		// List<ProductFeedback> product_feedback = new ArrayList<ProductFeedback>();

		List<ProductFeedback> product_feedback = capStoreFeedback.findByProduct(capStoreProduct.findById(product_Id).get());
		return product_feedback;
	}

	public List<ProductFeedback> getProductFeedBack( int customerId) {
		List<ProductFeedback> productFeedBack;

		productFeedBack = capStoreFeedback.findByCustomer(capStoreCustomer.findById(customerId).get());
		
		return productFeedBack;
	}
	
	public ProductFeedback updateFeedback(int feedback_Id, ProductFeedback productFeedBack)
	{

		ProductFeedback productFeedBack_update;
		
		productFeedBack_update = capStoreFeedback.findById(feedback_Id);
		productFeedBack.setId(productFeedBack_update.getId());
		capStoreFeedback.save(productFeedBack);
		return productFeedBack;
	}
	
	
	
	
	
	public List<Product> getProductByBrandName(String productBrand)
	{
		return capStoreProduct.findByProductBrand(productBrand);
	}
	public List<Product> getProductByCategory(String category)
	{
		return capStoreProduct.findByProductCategory(category);
	}
	public List<Product> getProductByName(String productName)
	{
		return capStoreProduct.findByProductName(productName);
	}
	
	
	
	
	
	
}
