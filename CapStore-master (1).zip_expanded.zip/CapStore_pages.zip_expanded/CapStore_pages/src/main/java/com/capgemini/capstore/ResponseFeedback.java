package com.capgemini.capstore;

public class ResponseFeedback {

	RestResponseFeedback restResponseFeedback;

	public RestResponseFeedback getRestResponseFeedback() {
		return restResponseFeedback;
	}

	public void setRestResponseFeedback(RestResponseFeedback restResponseFeedback) {
		this.restResponseFeedback = restResponseFeedback;
	}

	public ResponseFeedback() {
		super();
		
	}
	
}
